from . import gloria_loss
from . import contrastive_loss
from . import segmentation_loss
